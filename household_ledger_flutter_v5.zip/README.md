# 뚜이뚜이 꼬미꼬미 부부 공동 가계부 (Flutter + Supabase)

본 프로젝트는 휴대폰 SMS 결제 문자를 실시간으로 자동 수집 및 분류하고, 부부가 실시간 데이터베이스(Supabase)를 통해 공동으로 지출과 예산을 관리할 수 있는 Flutter 기반 모바일 가계부 앱입니다.

## 주요 기능
1. 자동 SMS 결제 문자 파싱 및 카테고리 분류 엔진 (국내 주요 카드사 지원)
2. 부부 실시간 데이터 동기화 (Supabase Realtime)
3. 6자리 초대 코드 기반 커플 연결 (유효시간 10분)
4. 공동 내역 vs 개인 비공개 내역 분리
5. 디자인 100% 동일 UI/UX 구현 (세이지 그린 테마)

## 데이터베이스 설정 (Supabase)
1. `supabase_schema.sql` 파일을 실행하여 테이블 및 보안 정책 생성
2. `lib/services/supabase_service.dart`에 Supabase URL 및 anonKey 등록

## 실행 방법
```bash
flutter pub get
flutter run
```

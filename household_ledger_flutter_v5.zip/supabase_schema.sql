-- ====================================================================
-- 뚜이뚜이 꼬미꼬미 부부 공동 가계부 (Supabase Database Migration Schema)
-- ====================================================================

-- 1. 커플(부부) 테이블
CREATE TABLE IF NOT EXISTS couples (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invite_code VARCHAR(6) UNIQUE,               -- 6자리 무작위 초대 코드 (예: X7K9P2)
    code_created_at TIMESTAMP WITH TIME ZONE,    -- 초대 코드 생성 일시 (10분 만료 체크용)
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. 사용자 프로필 테이블 (Supabase Auth 사용자 확장)
CREATE TABLE IF NOT EXISTS profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email VARCHAR(255) UNIQUE NOT NULL,
    nickname VARCHAR(50) NOT NULL DEFAULT '꼬미꼬미',
    couple_id UUID REFERENCES couples(id) ON DELETE SET NULL, -- 소속된 부부 ID
    role VARCHAR(10) CHECK (role IN ('husband', 'wife', 'member')) DEFAULT 'member',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. 카테고리 테이블
CREATE TABLE IF NOT EXISTS categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    couple_id UUID REFERENCES couples(id) ON DELETE CASCADE,
    name VARCHAR(50) NOT NULL,
    icon VARCHAR(50),
    type VARCHAR(10) CHECK (type IN ('expense', 'income')) DEFAULT 'expense',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. 지출/수입 거래 내역 테이블
CREATE TABLE IF NOT EXISTS transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    couple_id UUID REFERENCES couples(id) ON DELETE CASCADE NOT NULL,
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    registered_by VARCHAR(50) NOT NULL DEFAULT '나',
    category_name VARCHAR(50) NOT NULL DEFAULT '식비/카페',
    merchant_name VARCHAR(100) NOT NULL,
    amount DECIMAL(12, 2) NOT NULL DEFAULT 0,
    transaction_type VARCHAR(10) CHECK (transaction_type IN ('expense', 'income', 'cancel', 'transfer')) DEFAULT 'expense',
    scope VARCHAR(10) CHECK (scope IN ('shared', 'personal')) DEFAULT 'shared', -- 'shared': 부부 공유, 'personal': 개인 비공개
    paid_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    card_or_bank_name VARCHAR(50),
    raw_sms_text TEXT,
    memo TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Realtime publication 추가 (거래 내역 실시간 동기화)
ALTER PUBLICATION supabase_realtime ADD TABLE transactions;

-- ====================================================================
-- RLS (Row Level Security) 보안 정책 설정
-- ====================================================================

ALTER TABLE couples ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

-- Couples 정책: 부부 구성원은 커플 정보를 읽을 수 있음
CREATE POLICY "Couples read policy" ON couples
    FOR SELECT USING (
        auth.uid() IN (SELECT id FROM profiles WHERE couple_id = couples.id)
    );

-- Profiles 정책: 자신의 프로필 읽기/수정 및 같은 부부의 프로필 읽기 허용
CREATE POLICY "Profiles read policy" ON profiles
    FOR SELECT USING (
        auth.uid() = id OR couple_id IN (SELECT couple_id FROM profiles WHERE id = auth.uid())
    );

CREATE POLICY "Profiles update policy" ON profiles
    FOR UPDATE USING (auth.uid() = id);

-- Transactions 정책:
-- 1) 'shared' (부부 공동 내역): 같은 couple_id에 속한 사용자는 모두 읽기/쓰기 가능
-- 2) 'personal' (개인 비공개 내역): 해당 내역을 작성한 본인(user_id = auth.uid())만 읽기/쓰기 가능
CREATE POLICY "Transactions select policy" ON transactions
    FOR SELECT USING (
        (scope = 'shared' AND couple_id IN (SELECT couple_id FROM profiles WHERE id = auth.uid()))
        OR
        (scope = 'personal' AND user_id = auth.uid())
    );

CREATE POLICY "Transactions insert policy" ON transactions
    FOR INSERT WITH CHECK (
        couple_id IN (SELECT couple_id FROM profiles WHERE id = auth.uid())
    );

CREATE POLICY "Transactions update_delete policy" ON transactions
    FOR ALL USING (
        (scope = 'shared' AND couple_id IN (SELECT couple_id FROM profiles WHERE id = auth.uid()))
        OR
        (user_id = auth.uid())
    );

-- ====================================================================
-- 부부 초대 코드 생성 및 연동 스토어드 프로시저 (RPC Functions)
-- ====================================================================

-- 1. 무작위 6자리 대문자+숫자 초대 코드 생성 및 발급 함수
CREATE OR REPLACE FUNCTION create_couple_invite()
RETURNS TABLE (invite_code VARCHAR(6), couple_id UUID)
LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    new_code VARCHAR(6);
    new_couple_id UUID;
BEGIN
    -- 6자리 무작위 알파벳/숫자 생성
    new_code := upper(substring(md5(random()::text) from 1 for 6));
    
    INSERT INTO couples (invite_code, code_created_at)
    VALUES (new_code, NOW())
    RETURNING id INTO new_couple_id;

    -- 생성자를 해당 커플에 연결
    UPDATE profiles
    SET couple_id = new_couple_id, role = 'husband'
    WHERE id = auth.uid();

    RETURN QUERY SELECT new_code, new_couple_id;
END;
$$;

-- 2. 초대 코드로 부부 연동 참여 함수 (10분 만료 검증 포함)
CREATE OR REPLACE FUNCTION join_couple_with_code(code_input VARCHAR(6))
RETURNS BOOLEAN
LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    target_couple_id UUID;
    code_time TIMESTAMP WITH TIME ZONE;
BEGIN
    SELECT id, code_created_at INTO target_couple_id, code_time
    FROM couples
    WHERE upper(invite_code) = upper(code_input);

    IF target_couple_id IS NULL THEN
        RAISE EXCEPTION '유효하지 않은 초대 코드입니다.';
    END IF;

    -- 10분(600초) 초과 여부 체크
    IF NOW() - code_time > INTERVAL '10 minutes' THEN
        RAISE EXCEPTION '초대 코드가 만료되었습니다. 새 코드를 발급받아 주세요.';
    END IF;

    -- 사용자 프로필에 couple_id 업데이트 및 부부 연동 완료
    UPDATE profiles
    SET couple_id = target_couple_id, role = 'wife'
    WHERE id = auth.uid();

    RETURN TRUE;
END;
$$;

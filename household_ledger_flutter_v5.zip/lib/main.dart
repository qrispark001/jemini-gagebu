import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'theme/app_theme.dart';
import 'providers/ledger_provider.dart';
import 'screens/home_screen.dart';
import 'screens/ledger_screen.dart';
import 'screens/stats_screen.dart';
import 'screens/couple_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/record_modal.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => LedgerProvider(),
      child: const HouseholdLedgerApp(),
    ),
  );
}

class HouseholdLedgerApp extends StatelessWidget {
  const HouseholdLedgerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '뚜이뚜이 꼬미꼬미 가계부',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: const MainTabScaffold(),
    );
  }
}

class MainTabScaffold extends StatefulWidget {
  const MainTabScaffold({super.key});

  @override
  State<MainTabScaffold> createState() => _MainTabScaffoldState();
}

class _MainTabScaffoldState extends State<MainTabScaffold> {
  int _currentIndex = 0;

  void _openRecordModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        child: const RecordModal(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> screens = [
      HomeScreen(onOpenRecordModal: _openRecordModal),
      LedgerScreen(onOpenRecordModal: _openRecordModal),
      const SizedBox(), // Floating (+) button placeholder
      const StatsScreen(),
      const CoupleScreen(),
      const SettingsScreen(),
    ];

    return Scaffold(
      body: SafeArea(
        child: screens[_currentIndex],
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Color(0xFFEEEEEE), width: 1)),
        ),
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildNavItem(0, Icons.home_outlined, Icons.home, '홈'),
            _buildNavItem(1, Icons.account_balance_wallet_outlined, Icons.account_balance_wallet, '가계부'),
            
            // Central Circular (+) Add Button
            GestureDetector(
              onTap: _openRecordModal,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: const BoxDecoration(
                      color: AppTheme.primaryGreen,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.add, color: Colors.white, size: 28),
                  ),
                  const SizedBox(height: 2),
                  const Text(
                    '기록',
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: AppTheme.primaryGreen),
                  ),
                ],
              ),
            ),

            _buildNavItem(3, Icons.show_chart_outlined, Icons.show_chart, '통계'),
            _buildNavItem(4, Icons.favorite_border, Icons.favorite, '함께'),
            _buildNavItem(5, Icons.settings_outlined, Icons.settings, '설정'),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(int index, IconData icon, IconData activeIcon, String label) {
    final isSelected = _currentIndex == index;
    return InkWell(
      onTap: () {
        setState(() {
          _currentIndex = index;
        });
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isSelected ? activeIcon : icon,
            color: isSelected ? AppTheme.primaryGreen : AppTheme.textSecondary,
            size: 24,
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              color: isSelected ? AppTheme.primaryGreen : AppTheme.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

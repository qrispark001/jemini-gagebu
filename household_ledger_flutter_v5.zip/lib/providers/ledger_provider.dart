import 'package:flutter/material.dart';
import '../models/transaction.dart';
import '../models/ledger_settings.dart';
import '../services/supabase_service.dart';
import '../services/sms_parser_service.dart';
import '../services/sms_test_samples.dart';
import '../services/csv_export_service.dart';

class LedgerProvider extends ChangeNotifier {
  final LedgerSettings _settings = LedgerSettings();
  final List<TransactionItem> _transactions = [];
  final SupabaseService _supabaseService = SupabaseService();

  DateTime _selectedMonth = DateTime(2026, 10, 1);
  VisibilityScope _currentScope = VisibilityScope.shared;
  String _searchQuery = '';

  // 부부 연결 상태
  bool _isCoupleConnected = false;
  String? _coupleId;
  String? _activeInviteCode;

  LedgerSettings get settings => _settings;
  List<TransactionItem> get transactions => _transactions;
  DateTime get selectedMonth => _selectedMonth;
  VisibilityScope get currentScope => _currentScope;
  String get searchQuery => _searchQuery;

  bool get isCoupleConnected => _isCoupleConnected;
  String? get activeInviteCode => _activeInviteCode;

  // Total Income / Expense calculations
  double get totalIncome => _transactions
      .where((t) => t.type == TransactionType.income)
      .fold(0, (sum, t) => sum + t.amount);

  double get totalExpense => _transactions
      .where((t) => t.type == TransactionType.expense)
      .fold(0, (sum, t) => sum + t.amount);

  double get remainingBudget => _settings.monthlyBudget - totalExpense;

  void addTransaction(TransactionItem item) {
    _transactions.insert(0, item);
    notifyListeners();
  }

  /// SMS 문자 수신 시 자동 파싱 후 가계부 등록
  ParsedSmsResult processAndAddSms(String smsText) {
    final parsed = SmsParserService.parse(smsText);
    if (parsed.isSuccess) {
      final newItem = TransactionItem(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        merchantName: parsed.merchantName,
        amount: parsed.amount,
        category: parsed.category,
        type: TransactionType.expense,
        paidAt: parsed.paidAt,
        cardOrBankName: parsed.cardName,
        scope: VisibilityScope.shared,
        registeredBy: _settings.myNickname,
        rawSmsText: parsed.rawText,
      );
      addTransaction(newItem);
    }
    return parsed;
  }

  /// 모든 가상 카드사 SMS 테스트 샘플 8건 일괄 로드
  int loadAllSampleTransactions() {
    int count = 0;
    for (var sample in SmsTestSamples.sampleList) {
      final parsed = SmsParserService.parse(sample.rawText);
      if (parsed.isSuccess) {
        final item = TransactionItem(
          id: '${DateTime.now().millisecondsSinceEpoch}_$count',
          merchantName: parsed.merchantName,
          amount: parsed.amount,
          category: parsed.category,
          type: TransactionType.expense,
          paidAt: parsed.paidAt,
          cardOrBankName: parsed.cardName,
          scope: VisibilityScope.shared,
          registeredBy: _settings.myNickname,
          rawSmsText: parsed.rawText,
        );
        _transactions.insert(0, item);
        count++;
      }
    }
    notifyListeners();
    return count;
  }

  /// 현재 지출 내역 CSV 텍스트 반환 (Excel 한글 깨짐 방지 BOM 적용)
  String exportTransactionsToCsv() {
    return CsvExportService.generateTransactionsCsv(_transactions);
  }

  void updateSettings({
    String? appTitle,
    String? ledgerName,
    String? myNickname,
  }) {
    if (appTitle != null) _settings.appTitle = appTitle;
    if (ledgerName != null) _settings.ledgerName = ledgerName;
    if (myNickname != null) _settings.myNickname = myNickname;
    notifyListeners();
  }

  void setScope(VisibilityScope scope) {
    _currentScope = scope;
    notifyListeners();
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  void changeMonth(int offset) {
    _selectedMonth = DateTime(_selectedMonth.year, _selectedMonth.month + offset, 1);
    notifyListeners();
  }

  // 부부 초대 코드 생성
  Future<String> generateCoupleInviteCode() async {
    final code = await _supabaseService.generateInviteCode();
    _activeInviteCode = code;
    notifyListeners();
    return code;
  }

  // 초대 코드로 부부 연결
  Future<Map<String, dynamic>> connectCoupleWithCode(String code) async {
    final result = await _supabaseService.joinCoupleWithCode(code);
    if (result['success'] == true) {
      _isCoupleConnected = true;
      _coupleId = "couple-linked-id";
      notifyListeners();
    }
    return result;
  }
}

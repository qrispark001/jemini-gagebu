enum TransactionType { expense, income, cancel, transfer }
enum VisibilityScope { shared, myOnly, partnerOnly }

class TransactionItem {
  final String id;
  final double amount;
  final String merchant;
  final String category;
  final DateTime date;
  final String paymentMethod;
  final VisibilityScope scope;
  final String? memo;
  final TransactionType type;

  TransactionItem({
    required this.id,
    required this.amount,
    required this.merchant,
    required this.category,
    required this.date,
    required this.paymentMethod,
    required this.scope,
    this.memo,
    this.type = TransactionType.expense,
  });
}

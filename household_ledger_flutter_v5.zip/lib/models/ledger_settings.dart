class LedgerSettings {
  String appTitle;
  String ledgerName;
  String myNickname;
  String partnerNickname;
  bool isSmsAutoSyncEnabled;
  bool isSmsListenerEnabled;
  double monthlyBudget;

  LedgerSettings({
    this.appTitle = '뚜이뚜이 꼬미꼬미 가계부',
    this.ledgerName = '뚜이뚜이 꼬미꼬미 가계부',
    this.myNickname = '꼬미꼬미',
    this.partnerNickname = '뚜이뚜이',
    this.isSmsAutoSyncEnabled = true,
    this.isSmsListenerEnabled = true,
    this.monthlyBudget = 2500000.0,
  });
}

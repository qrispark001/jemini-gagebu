import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/ledger_provider.dart';

class CoupleScreen extends StatefulWidget {
  const CoupleScreen({super.key});

  @override
  State<CoupleScreen> createState() => _CoupleScreenState();
}

class _CoupleScreenState extends State<CoupleScreen> {
  final TextEditingController _codeController = TextEditingController();
  bool _isConnecting = false;

  @override
  void dispose() {
    _codeController.dispose();
    super.dispose();
  }

  void _showGenerateInviteModal(BuildContext context, LedgerProvider provider) async {
    final code = await provider.generateCoupleInviteCode();

    if (!mounted) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppTheme.borderGrey,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 20),
              const Icon(Icons.qr_code_2, size: 60, color: AppTheme.primaryGreen),
              const SizedBox(height: 12),
              const Text(
                '배우자 초대 코드 발급',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
              ),
              const SizedBox(height: 6),
              const Text(
                '아래 6자리 코드를 배우자의 앱에 입력해 주시면 바로 연결됩니다.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
              ),
              const SizedBox(height: 24),

              // 6자리 초대 코드 전용 디스플레이 박스
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                decoration: BoxDecoration(
                  color: AppTheme.primaryLightGreen,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppTheme.primaryGreen.withOpacity(0.3)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      code,
                      style: const TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 6,
                        color: AppTheme.primaryGreen,
                      ),
                    ),
                    const SizedBox(width: 12),
                    IconButton(
                      icon: const Icon(Icons.copy, color: AppTheme.primaryGreen),
                      onPressed: () {
                        Clipboard.setData(ClipboardData(text: code));
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('초대 코드가 클립보드에 복사되었습니다.')),
                        );
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.access_time, size: 14, color: AppTheme.warningText),
                  SizedBox(width: 4),
                  Text(
                    '유효 시간: 10분 남음',
                    style: TextStyle(fontSize: 12, color: AppTheme.warningText, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('확인 완료'),
                ),
              ),
              const SizedBox(height: 12),
            ],
          ),
        );
      },
    );
  }

  void _showJoinWithCodeModal(BuildContext context, LedgerProvider provider) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            left: 24,
            right: 24,
            top: 24,
            bottom: MediaQuery.of(context).viewInsets.bottom + 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppTheme.borderGrey,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                '초대 코드로 부부 연결',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
              ),
              const SizedBox(height: 6),
              const Text(
                '배우자에게서 받은 6자리 초대 코드를 입력해 주세요.',
                style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: _codeController,
                textAllCaps: true,
                maxLength: 6,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, letterSpacing: 8),
                decoration: InputDecoration(
                  hintText: 'X7K9P2',
                  counterText: '',
                  fillColor: AppTheme.bgOffWhite,
                  filled: true,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: const BorderSide(color: AppTheme.borderGrey),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isConnecting
                      ? null
                      : () async {
                          setState(() => _isConnecting = true);
                          final result = await provider.connectCoupleWithCode(_codeController.text);
                          setState(() => _isConnecting = false);

                          if (mounted) {
                            Navigator.pop(context);
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text(result['message'])),
                            );
                          }
                        },
                  child: _isConnecting
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                        )
                      : const Text('부부 연결하기'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<LedgerProvider>(context);

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 1. Header Card ("나의 기록에서, 우리의 기록으로.")
          Card(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  // Top Avatars
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: const BoxDecoration(
                          color: Color(0xFFE0EFE3),
                          shape: BoxShape.circle,
                        ),
                        alignment: Alignment.center,
                        child: const Text('나', style: TextStyle(fontSize: 18, color: AppTheme.primaryGreen, fontWeight: FontWeight.bold)),
                      ),
                      const SizedBox(width: 16),
                      Icon(
                        provider.isCoupleConnected ? Icons.favorite : Icons.favorite_border,
                        color: provider.isCoupleConnected ? Colors.redAccent : AppTheme.textSecondary,
                        size: 26,
                      ),
                      const SizedBox(width: 16),
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          color: provider.isCoupleConnected ? AppTheme.peachBg : Colors.grey[200],
                          shape: BoxShape.circle,
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          '짝',
                          style: TextStyle(
                            fontSize: 18,
                            color: provider.isCoupleConnected ? AppTheme.peachText : Colors.grey[500],
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // Connection Status Text
                  Text(
                    provider.isCoupleConnected ? '부부 연결 완료 💚🧡' : '나의 기록에서, 우리의 기록으로.',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    provider.isCoupleConnected
                        ? '배우자와 함께 실시간으로 가계부를 관리 중입니다.'
                        : '공동 내역과 예산은 함께 보고,\n개인 내역은 작성자만 확인할 수 있어요.',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 13, color: AppTheme.textSecondary, height: 1.4),
                  ),
                  const SizedBox(height: 24),
                  const Divider(height: 1, color: AppTheme.borderGrey),
                  const SizedBox(height: 16),

                  // Member Row
                  Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: const BoxDecoration(
                          color: AppTheme.primaryLightGreen,
                          shape: BoxShape.circle,
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          provider.settings.myNickname.isNotEmpty ? provider.settings.myNickname[0] : '꼬',
                          style: const TextStyle(fontSize: 14, color: AppTheme.primaryGreen, fontWeight: FontWeight.bold),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        provider.settings.myNickname,
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                      ),
                      const Spacer(),
                      Text(
                        provider.isCoupleConnected ? '부부 공동 관리자' : '가계부 관리자',
                        style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                      ),
                      const SizedBox(width: 4),
                      const Icon(Icons.check, size: 16, color: AppTheme.primaryGreen),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // Action Buttons (Invite or Join)
                  if (!provider.isCoupleConnected) ...[
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () => _showGenerateInviteModal(context, provider),
                        icon: const Icon(Icons.qr_code, size: 20),
                        label: const Text('배우자 초대 QR 및 6자리 코드 만들기'),
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    GestureDetector(
                      onTap: () => _showJoinWithCodeModal(context, provider),
                      child: const Text(
                        '받은 초대 코드로 연결하기',
                        style: TextStyle(fontSize: 13, color: AppTheme.primaryGreen, fontWeight: FontWeight.bold, decoration: TextDecoration.underline),
                      ),
                    ),
                  ] else ...[
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryLightGreen,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(Icons.sync, color: AppTheme.primaryGreen, size: 20),
                          SizedBox(width: 8),
                          Text(
                            '실시간 부부 동기화 활성화됨',
                            style: TextStyle(fontSize: 13, color: AppTheme.primaryGreen, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // 2. Security & Permission Card ("공유는 필요한 만큼만")
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: const [
                      Icon(Icons.lock_outline, size: 20, color: AppTheme.textPrimary),
                      SizedBox(width: 8),
                      Text(
                        '공유는 필요한 만큼만',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  _buildCheckRow('공동 내역은 두 분이 함께 수정'),
                  const SizedBox(height: 10),
                  _buildCheckRow('개인 내역은 작성자에게만 공개'),
                  const SizedBox(height: 10),
                  _buildCheckRow('초대 코드는 10분 후 자동 만료'),
                  const SizedBox(height: 10),
                  _buildCheckRow('다른 기기 수정 충돌 자동 감지'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCheckRow(String text) {
    return Row(
      children: [
        const Icon(Icons.check, size: 16, color: AppTheme.primaryGreen),
        const SizedBox(width: 8),
        Text(
          text,
          style: const TextStyle(fontSize: 13, color: AppTheme.textSecondary),
        ),
      ],
    );
  }
}

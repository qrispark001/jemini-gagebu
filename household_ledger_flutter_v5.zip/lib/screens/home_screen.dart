import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/ledger_provider.dart';
import '../services/sms_test_samples.dart';

class HomeScreen extends StatelessWidget {
  final VoidCallback onOpenRecordModal;

  const HomeScreen({super.key, required this.onOpenRecordModal});

  void _showSmsTestDialog(BuildContext context, LedgerProvider provider) {
    final sample = SmsTestSamples.getRandomSample();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Row(
            children: [
              const Icon(Icons.sms_outlined, color: AppTheme.primaryGreen),
              const SizedBox(width: 8),
              Text('${sample.cardCompany} SMS 테스트', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('가상 결제 문자를 수신하여 파싱 알고리즘을 테스트합니다:', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.bgLight,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.borderGrey),
                ),
                child: Text(sample.rawText, style: const TextStyle(fontSize: 12, fontFamily: 'monospace')),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('취소', style: TextStyle(color: AppTheme.textSecondary)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primaryGreen),
              onPressed: () {
                final result = provider.processAndAddSms(sample.rawText);
                Navigator.pop(context);

                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    backgroundColor: AppTheme.primaryGreen,
                    content: Text('✓ [${result.cardName}] ${result.merchantName} ${result.amount.toInt()}원 -> [${result.category}] 자동 분류 완료!'),
                  ),
                );
              },
              child: const Text('파싱 및 가계부 등록'),
            ),
          ],
        );
      },
    );
  }

  void _loadAllSamples(BuildContext context, LedgerProvider provider) {
    int count = provider.loadAllSampleTransactions();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppTheme.primaryGreen,
        content: Text('✓ 8개 주요 카드사 SMS 샘플 내역 총 $count건이 추가되었습니다.'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<LedgerProvider>(context);
    final settings = provider.settings;

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 1. Top Update Banner (Applies when update is ready)
          Container(
            color: AppTheme.primaryLightGreen,
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.phone_android, color: AppTheme.primaryGreen, size: 22),
                    const SizedBox(width: 8),
                    const Text(
                      '업데이트 설치 준비 완료',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      '현재 1.6.0 · 최신 1.7.1',
                      style: TextStyle(
                        fontSize: 12,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                const Text(
                  'Android 설치 확인 대기 · 취소하면 현재 버전을 계속 사용합니다',
                  style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    ElevatedButton.icon(
                      onPressed: () {},
                      icon: const Icon(Icons.file_download_outlined, size: 18),
                      label: const Text('업데이트 설치'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.primaryGreen,
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      ),
                    ),
                    const SizedBox(width: 8),
                    TextButton(
                      onPressed: () {},
                      child: const Text(
                        '직접 다운로드 안내',
                        style: TextStyle(color: AppTheme.textSecondary, fontSize: 13),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  '다운로드한 앱은 Android 설치 화면에서 직접 확인해야 적용됩니다.',
                  style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
                ),
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Sub App Bar Row
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppTheme.borderGrey),
                      ),
                      child: const Text(
                        '뚜이뚜이 꼬미꼬미 가계부 / 뚜이뚜... v1.6.0',
                        style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.settings_outlined, size: 20),
                      onPressed: () {},
                    ),
                    IconButton(
                      icon: const Icon(Icons.refresh, size: 20),
                      onPressed: () {},
                    ),
                    // Couple Avatars
                    Row(
                      children: [
                        Container(
                          width: 26,
                          height: 26,
                          decoration: const BoxDecoration(
                            color: Color(0xFFDCECDC),
                            shape: BoxShape.circle,
                          ),
                          alignment: Alignment.center,
                          child: const Text('나', style: TextStyle(fontSize: 11, color: AppTheme.primaryGreen, fontWeight: FontWeight.bold)),
                        ),
                        Container(
                          width: 26,
                          height: 26,
                          margin: const EdgeInsets.only(left: 4),
                          decoration: const BoxDecoration(
                            color: AppTheme.peachBg,
                            shape: BoxShape.circle,
                          ),
                          alignment: Alignment.center,
                          child: const Text('짝', style: TextStyle(fontSize: 11, color: AppTheme.peachText, fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // Main Header Title
                const Text(
                  'OUR EVERYDAY, TOGETHER',
                  style: TextStyle(
                    fontSize: 11,
                    letterSpacing: 1.2,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textSecondary,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(
                      settings.appTitle,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                    const Text(
                      '.',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.primaryGreen,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                const Text(
                  '오늘의 기록이, 우리 내일의 여유가 되도록.',
                  style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
                ),
                const SizedBox(height: 20),

                // Date & Action Buttons
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.chevron_left, size: 22),
                      onPressed: () => provider.changeMonth(-1),
                    ),
                    Text(
                      '${provider.selectedMonth.year}년 ${provider.selectedMonth.month}월',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    IconButton(
                      icon: const Icon(Icons.chevron_right, size: 22),
                      onPressed: () => provider.changeMonth(1),
                    ),
                    const Spacer(),
                    OutlinedButton(
                      onPressed: () => _showSmsTestDialog(context, provider),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      ),
                      child: const Text('SMS 테스트'),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton.icon(
                      onPressed: onOpenRecordModal,
                      icon: const Icon(Icons.add, size: 18),
                      label: const Text('내역 추가'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // Feature Card: 문자 자동 수집·분류
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: AppTheme.primaryLightGreen,
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: const Icon(Icons.chat_bubble_outline, color: AppTheme.primaryGreen, size: 24),
                            ),
                            const SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text(
                                  '문자에서 기록까지',
                                  style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
                                ),
                                SizedBox(height: 2),
                                Text(
                                  '문자 자동 수집·분류',
                                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                                ),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        const Text(
                          '저장한 기간과 계좌·카드 끝 4자리 조건으로 문자를 정리해요. 정밀 자동 분류·등록은 문자 수집형 1.7.0부터 지원합니다.',
                          style: TextStyle(fontSize: 13, color: AppTheme.textSecondary, height: 1.4),
                        ),
                        const SizedBox(height: 16),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            _buildStatusChip('✓ 새 문자 설정 켜짐', isGreenBorder: true),
                            _buildStatusChip('문자함 확인 켜짐', isGreenBorder: true),
                            _buildStatusChip('정밀 자동 분류 · 1.7.0 필요', isWarning: true),
                          ],
                        ),
                        const Divider(height: 28, color: AppTheme.borderGrey),
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton.icon(
                                icon: const Icon(Icons.play_arrow, size: 18),
                                label: const Text('가상 문자 수신 테스트'),
                                onPressed: () => _showSmsTestDialog(context, provider),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primaryGreen),
                                icon: const Icon(Icons.playlist_add, size: 18),
                                label: const Text('샘플 내역 8건 추가'),
                                onPressed: () => _loadAllSamples(context, provider),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusChip(String label, {bool isGreenBorder = false, bool isWarning = false}) {
    Color bg = Colors.white;
    Color textColor = AppTheme.textPrimary;
    Border border = Border.all(color: AppTheme.borderGrey);

    if (isGreenBorder) {
      bg = AppTheme.primaryLightGreen.withOpacity(0.4);
      border = Border.all(color: AppTheme.primaryGreen.withOpacity(0.5));
      textColor = AppTheme.primaryGreen;
    } else if (isWarning) {
      bg = AppTheme.warningBg;
      border = Border.all(color: Colors.transparent);
      textColor = AppTheme.warningText;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
        border: border,
      ),
      child: Text(
        label,
        style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: textColor),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/ledger_provider.dart';
import '../models/transaction.dart';

class LedgerScreen extends StatefulWidget {
  final VoidCallback onOpenRecordModal;

  const LedgerScreen({super.key, required this.onOpenRecordModal});

  @override
  State<LedgerScreen> createState() => _LedgerScreenState();
}

class _LedgerScreenState extends State<LedgerScreen> {
  int _selectedSubTab = 0; // 0: 내역 목록, 1: 달력으로 보기, 2: 우리집 예산
  String _selectedFilterType = '전체';

  void _showCsvExportDialog(BuildContext context, LedgerProvider provider) {
    String csvText = provider.exportTransactionsToCsv();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Row(
            children: const [
              Icon(Icons.file_download_outlined, color: AppTheme.primaryGreen),
              SizedBox(width: 8),
              Text('CSV/Excel 내보내기 리포트', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Excel 한글 깨짐 방지(UTF-8 BOM)가 적용된 CSV 파일 내용입니다:', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
              const SizedBox(height: 10),
              Container(
                maxHeight: 200,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.bgLight,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.borderGrey),
                ),
                child: SingleChildScrollView(
                  child: Text(
                    csvText.isEmpty ? '내역이 없습니다.' : csvText,
                    style: const TextStyle(fontSize: 11, fontFamily: 'monospace'),
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('닫기', style: TextStyle(color: AppTheme.textSecondary)),
            ),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primaryGreen),
              icon: const Icon(Icons.copy, size: 16),
              label: const Text('CSV 복사 및 저장'),
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    backgroundColor: AppTheme.primaryGreen,
                    content: Text('✓ CSV 지출 보고서 데이터가 클립보드에 복사되었습니다.'),
                  ),
                );
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<LedgerProvider>(context);

    final filteredTransactions = provider.transactions.where((t) {
      if (_selectedFilterType == '지출' && t.type != TransactionType.expense) return false;
      if (_selectedFilterType == '수입' && t.type != TransactionType.income) return false;
      if (_selectedFilterType == '취소' && t.type != TransactionType.cancel) return false;
      if (_selectedFilterType == '이체' && t.type != TransactionType.transfer) return false;

      if (provider.searchQuery.isNotEmpty) {
        final query = provider.searchQuery.toLowerCase();
        final matchMerchant = t.merchantName.toLowerCase().contains(query);
        final matchCategory = t.category.toLowerCase().contains(query);
        final matchCard = t.cardOrBankName.toLowerCase().contains(query);
        return matchMerchant || matchCategory || matchCard;
      }
      return true;
    }).toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header Title
          Row(
            children: const [
              Text(
                '수입과 지출',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.textPrimary,
                ),
              ),
              Text(
                '.',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryGreen,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          const Text(
            '우리의 돈이 어디로 흐르는지 차근차근 살펴보아요.',
            style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
          ),
          const SizedBox(height: 16),

          // Date & Action Buttons Row
          Row(
            children: [
              IconButton(
                icon: const Icon(Icons.chevron_left, size: 22),
                onPressed: () => provider.changeMonth(-1),
              ),
              Text(
                '${provider.selectedMonth.year}년 ${provider.selectedMonth.month}월',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              IconButton(
                icon: const Icon(Icons.chevron_right, size: 22),
                onPressed: () => provider.changeMonth(1),
              ),
              const Spacer(),
              OutlinedButton(
                onPressed: () {},
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                ),
                child: const Text('빠른 입력'),
              ),
              const SizedBox(width: 8),
              ElevatedButton.icon(
                onPressed: widget.onOpenRecordModal,
                icon: const Icon(Icons.add, size: 18),
                label: const Text('내역 추가'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Sub Tab Bar (내역 목록 / 달력으로 보기 / 우리집 예산)
          Row(
            children: [
              _buildSubTab(0, '내역 목록'),
              const SizedBox(width: 20),
              _buildSubTab(1, '달력으로 보기'),
              const SizedBox(width: 20),
              _buildSubTab(2, '우리집 예산'),
            ],
          ),
          const Divider(height: 1, color: AppTheme.borderGrey),
          const SizedBox(height: 16),

          // Scope Chips Row
          Row(
            children: [
              _buildScopeChip(
                label: '우리 함께',
                isSelected: provider.currentScope == VisibilityScope.shared,
                onTap: () => provider.setScope(VisibilityScope.shared),
              ),
              const SizedBox(width: 8),
              _buildScopeChip(
                label: '꼬미꼬미',
                isSelected: provider.currentScope == VisibilityScope.partnerOnly,
                onTap: () => provider.setScope(VisibilityScope.partnerOnly),
              ),
              const SizedBox(width: 8),
              _buildScopeChip(
                label: '🔒 내 개인 내역',
                isSelected: provider.currentScope == VisibilityScope.myOnly,
                onTap: () => provider.setScope(VisibilityScope.myOnly),
              ),
              const Spacer(),
              const Text(
                '내게 공개된 기록 기준',
                style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Filter Card Box
          Card(
            color: const Color(0xFFF7F8F7),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Filter Pills Row
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: const Color(0xFFECECEC),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: ['전체', '지출', '수입', '취소', '이체'].map((label) {
                              final isSelected = _selectedFilterType == label;
                              return GestureDetector(
                                onTap: () => setState(() => _selectedFilterType = label),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: isSelected ? Colors.white : Colors.transparent,
                                    borderRadius: BorderRadius.circular(8),
                                    boxShadow: isSelected
                                        ? [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 4)]
                                        : null,
                                  ),
                                  child: Text(
                                    label,
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                      color: isSelected ? AppTheme.textPrimary : AppTheme.textSecondary,
                                    ),
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // CSV & Dropdown Controls
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: AppTheme.borderGrey),
                        ),
                        child: Row(
                          children: const [
                            Text('최신순', style: TextStyle(fontSize: 12, color: AppTheme.textPrimary)),
                            Icon(Icons.arrow_drop_down, size: 18),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: AppTheme.borderGrey),
                        ),
                        child: Row(
                          children: const [
                            Text('전체', style: TextStyle(fontSize: 12, color: AppTheme.textPrimary)),
                            Icon(Icons.arrow_drop_down, size: 18),
                          ],
                        ),
                      ),
                      const Spacer(),
                      OutlinedButton.icon(
                        onPressed: () => _showCsvExportDialog(context, provider),
                        icon: const Icon(Icons.file_download_outlined, size: 16),
                        label: const Text('CSV 다운로드'),
                        style: OutlinedButton.styleFrom(
                          backgroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          textStyle: const TextStyle(fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // Search Field
                  TextField(
                    onChanged: (val) => provider.setSearchQuery(val),
                    decoration: const InputDecoration(
                      hintText: '거래처·분류·계좌 검색',
                      prefixIcon: Icon(Icons.search, size: 20, color: AppTheme.textSecondary),
                      fillColor: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Count & Totals Summary Row
          Row(
            children: [
              Text(
                '${filteredTransactions.length}건의 기록',
                style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary),
              ),
              const Spacer(),
              Text(
                '수입 ${provider.totalIncome.toInt()}원  지출 ${provider.totalExpense.toInt()}원',
                style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Transaction List or Empty State
          if (filteredTransactions.isEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 40),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 54,
                      height: 54,
                      decoration: const BoxDecoration(
                        color: AppTheme.primaryLightGreen,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.eco_outlined, color: AppTheme.primaryGreen, size: 30),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      '아직 기록이 없어요',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      '홈의 [가상 문자 수신 테스트]를 눌러 샘플 내역을 추가해 보세요.',
                      style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
                    ),
                  ],
                ),
              ),
            )
          else
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: filteredTransactions.length,
              itemBuilder: (context, index) {
                final item = filteredTransactions[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    leading: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: const BoxDecoration(
                        color: AppTheme.primaryLightGreen,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.credit_card, color: AppTheme.primaryGreen, size: 20),
                    ),
                    title: Text(item.merchantName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    subtitle: Text('${item.cardOrBankName} · ${item.category}', style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                    trailing: Text(
                      '-${item.amount.toInt()} 원',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppTheme.textPrimary),
                    ),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _buildSubTab(int index, String title) {
    final isSelected = _selectedSubTab == index;
    return GestureDetector(
      onTap: () => setState(() => _selectedSubTab = index),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text(
              title,
              style: TextStyle(
                fontSize: 14,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                color: isSelected ? AppTheme.primaryGreen : AppTheme.textSecondary,
              ),
            ),
          ),
          Container(
            height: 2,
            width: 60,
            color: isSelected ? AppTheme.primaryGreen : Colors.transparent,
          ),
        ],
      ),
    );
  }

  Widget _buildScopeChip({required String label, required bool isSelected, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.primaryLightGreen : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? AppTheme.primaryGreen.withOpacity(0.5) : AppTheme.borderGrey,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            color: isSelected ? AppTheme.primaryGreen : AppTheme.textSecondary,
          ),
        ),
      ),
    );
  }
}

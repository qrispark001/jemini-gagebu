import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/ledger_provider.dart';
import '../models/transaction.dart';

class RecordModal extends StatefulWidget {
  const RecordModal({super.key});

  @override
  State<RecordModal> createState() => _RecordModalState();
}

class _RecordModalState extends State<RecordModal> {
  TransactionType _selectedType = TransactionType.expense;
  final TextEditingController _amountController = TextEditingController(text: '0');
  final TextEditingController _merchantController = TextEditingController();
  final TextEditingController _memoController = TextEditingController();
  String _selectedCategory = '식비';
  String _paymentMethod = '현금';
  VisibilityScope _scope = VisibilityScope.shared;

  final List<String> _categories = ['식비', '카페·간식', '장보기', '교통·차량', '쇼핑', '문화·여행'];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: const EdgeInsets.all(24),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            // Modal Header
            Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text(
                      'EVERY LITTLE RECORD',
                      style: TextStyle(fontSize: 11, letterSpacing: 1.1, color: AppTheme.textSecondary),
                    ),
                    SizedBox(height: 2),
                    Text(
                      '오늘의 작은 기록',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                    ),
                  ],
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.close, size: 24, color: AppTheme.textSecondary),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Type Segmented Controls
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: const Color(0xFFF2F4F2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  _buildTypeSegment(TransactionType.expense, '지출'),
                  _buildTypeSegment(TransactionType.income, '수입'),
                  _buildTypeSegment(TransactionType.cancel, '승인 취소'),
                  _buildTypeSegment(TransactionType.transfer, '이체'),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Amount Input Display
            const Text('금액', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
            const SizedBox(height: 8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Expanded(
                  child: TextField(
                    controller: _amountController,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      fillColor: Colors.transparent,
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                ),
                const Text('원', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppTheme.textSecondary)),
              ],
            ),
            const Divider(height: 1, color: AppTheme.borderGrey),
            const SizedBox(height: 16),

            // Category Chips
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _categories.map((cat) {
                final isSelected = _selectedCategory == cat;
                return ChoiceChip(
                  label: Text(cat),
                  selected: isSelected,
                  selectedColor: AppTheme.primaryLightGreen,
                  backgroundColor: const Color(0xFFF2F4F2),
                  labelStyle: TextStyle(
                    fontSize: 12,
                    color: isSelected ? AppTheme.primaryGreen : AppTheme.textPrimary,
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  ),
                  side: BorderSide.none,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  onSelected: (val) => setState(() => _selectedCategory = cat),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),

            // Merchant Field
            const Text('거래처', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
            const SizedBox(height: 6),
            TextField(
              controller: _merchantController,
              decoration: const InputDecoration(
                hintText: '어디에서 사용했나요?',
              ),
            ),
            const SizedBox(height: 16),

            // 2-Column Inputs (Date & Category Dropdown)
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('날짜', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: AppTheme.borderGrey),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: const [
                            Text('2026. 10. 27.', style: TextStyle(fontSize: 14, color: AppTheme.textPrimary)),
                            Icon(Icons.keyboard_arrow_down, size: 18, color: AppTheme.textSecondary),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('분류', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: AppTheme.borderGrey),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(_selectedCategory, style: const TextStyle(fontSize: 14, color: AppTheme.textPrimary)),
                            const Icon(Icons.keyboard_arrow_down, size: 18, color: AppTheme.textSecondary),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // 2-Column Inputs (Card/Bank & Scope)
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('카드·계좌', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                      const SizedBox(height: 6),
                      TextField(
                        decoration: InputDecoration(
                          hintText: _paymentMethod,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('공개 범위', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: AppTheme.borderGrey),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: const [
                            Text('우리 함께', style: TextStyle(fontSize: 14, color: AppTheme.textPrimary)),
                            Icon(Icons.keyboard_arrow_down, size: 18, color: AppTheme.textSecondary),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Memo Field
            const Text('메모', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
            const SizedBox(height: 6),
            TextField(
              controller: _memoController,
              maxLines: 2,
              decoration: const InputDecoration(
                hintText: '기억하고 싶은 내용을 남겨요',
              ),
            ),
            const SizedBox(height: 24),

            // Submit Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  final amount = double.tryParse(_amountController.text) ?? 0.0;
                  if (amount > 0) {
                    Provider.of<LedgerProvider>(context, listen: false).addTransaction(
                      TransactionItem(
                        id: DateTime.now().millisecondsSinceEpoch.toString(),
                        amount: amount,
                        merchant: _merchantController.text.isEmpty ? '미지정' : _merchantController.text,
                        category: _selectedCategory,
                        date: DateTime.now(),
                        paymentMethod: _paymentMethod,
                        scope: _scope,
                        memo: _memoController.text,
                        type: _selectedType,
                      ),
                    );
                  }
                  Navigator.pop(context);
                },
                child: const Text('기록 저장하기'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTypeSegment(TransactionType type, String label) {
    final isSelected = _selectedType == type;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _selectedType = type),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: isSelected ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
            boxShadow: isSelected
                ? [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 4)]
                : null,
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              color: isSelected ? AppTheme.textPrimary : AppTheme.textSecondary,
            ),
          ),
        ),
      ),
    );
  }
}

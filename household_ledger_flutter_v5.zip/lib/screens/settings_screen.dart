import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/ledger_provider.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _appTitleController;
  late TextEditingController _ledgerNameController;
  late TextEditingController _myNicknameController;

  @override
  void initState() {
    super.initState();
    final settings = Provider.of<LedgerProvider>(context, listen: false).settings;
    _appTitleController = TextEditingController(text: settings.appTitle);
    _ledgerNameController = TextEditingController(text: settings.ledgerName);
    _myNicknameController = TextEditingController(text: settings.myNickname);
  }

  @override
  void dispose() {
    _appTitleController.dispose();
    _ledgerNameController.dispose();
    _myNicknameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<LedgerProvider>(context);

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Top SMS Status & Sync Banner
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.primaryLightGreen.withOpacity(0.4),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  '2024-01-01 ~ 종료일 없음 · 계좌·카드 전체',
                  style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.chat_bubble_outline, size: 18),
                    label: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('문자 자동 수집'),
                        SizedBox(width: 4),
                        Icon(Icons.arrow_forward, size: 16),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(Icons.work_outline, size: 16, color: AppTheme.textSecondary),
                    SizedBox(width: 6),
                    Text(
                      '기기 대기 222건',
                      style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Main Title / Name Settings Card
          Card(
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryLightGreen,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Icon(Icons.edit_outlined, color: AppTheme.primaryGreen, size: 22),
                      ),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            'MAKE IT OURS',
                            style: TextStyle(fontSize: 11, letterSpacing: 1.1, color: AppTheme.textSecondary),
                          ),
                          SizedBox(height: 2),
                          Text(
                            '제목·이름 설정',
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    '우리집에 어울리는 이름과 문구로 바꿔 보세요.',
                    style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
                  ),
                  const SizedBox(height: 24),

                  // 1. App Title Field
                  const Text(
                    '앱 화면 제목',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _appTitleController,
                    onChanged: (val) {
                      provider.updateSettings(appTitle: val);
                    },
                    decoration: const InputDecoration(
                      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    '로그인한 가계부 안에서 표시되는 이름 · 최대 24자',
                    style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
                  ),
                  const SizedBox(height: 20),

                  // 2. Ledger Name Field
                  const Text(
                    '가계부 이름',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _ledgerNameController,
                    onChanged: (val) {
                      provider.updateSettings(ledgerName: val);
                    },
                    decoration: const InputDecoration(
                      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    '배우자와 함께 사용하는 가계부 이름',
                    style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
                  ),
                  const SizedBox(height: 20),

                  // 3. User Nickname Field
                  const Text(
                    '내 표시 이름',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _myNicknameController,
                    onChanged: (val) {
                      provider.updateSettings(myNickname: val);
                    },
                    decoration: const InputDecoration(
                      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    '기록 작성자와 부부 공유 화면에 표시돼요.',
                    style: TextStyle(fontSize: 11, color: AppTheme.textSecondary),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

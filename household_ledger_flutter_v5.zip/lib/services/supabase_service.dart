import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/transaction.dart';

class SupabaseService {
  static final SupabaseService _instance = SupabaseService._internal();
  factory SupabaseService() => _instance;
  SupabaseService._internal();

  SupabaseClient? _client;
  bool _isInitialized = false;
  bool get isInitialized => _isInitialized;

  // 데모/오프라인용 로컬 상태
  String? _mockCoupleId;
  String? _activeInviteCode;

  // Supabase 클라이언트 초기화
  Future<void> initialize({
    required String url,
    required String anonKey,
  }) async {
    try {
      await Supabase.initialize(
        url: url,
        anonKey: anonKey,
      );
      _client = Supabase.instance.client;
      _isInitialized = true;
      debugPrint("Supabase가 성공적으로 연동되었습니다.");
    } catch (e) {
      debugPrint("Supabase 초기화 오류 (데모 모드로 동작): $e");
    }
  }

  // 1. 6자리 부부 초대 코드 생성 함수
  Future<String> generateInviteCode() async {
    if (_isInitialized && _client != null) {
      try {
        final response = await _client!.rpc('create_couple_invite');
        if (response != null && response is List && response.isNotEmpty) {
          final code = response.first['invite_code'] as String;
          _activeInviteCode = code;
          return code;
        }
      } catch (e) {
        debugPrint("Supabase RPC 오류 (로컬 코드 생성 대체): $e");
      }
    }

    // 데모 / 오프라인 가상 6자리 무작위 코드 생성
    final constChars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final random = Random();
    final code = List.generate(6, (index) => constChars[random.nextInt(constChars.length)]).join();
    _activeInviteCode = code;
    _mockCoupleId = "couple-mock-uuid-123456";
    return code;
  }

  // 2. 받은 6자리 초대 코드로 부부 연동 참여 함수
  Future<Map<String, dynamic>> joinCoupleWithCode(String codeInput) async {
    final cleanCode = codeInput.trim().toUpperCase();

    if (cleanCode.length != 6) {
      return {'success': false, 'message': '6자리 코드를 정확히 입력해 주세요.'};
    }

    if (_isInitialized && _client != null) {
      try {
        final result = await _client!.rpc('join_couple_with_code', params: {'code_input': cleanCode});
        if (result == true) {
          return {'success': true, 'message': '부부 연결이 성공적으로 완료되었습니다!'};
        }
      } catch (e) {
        debugPrint("Supabase 연결 실패: $e");
      }
    }

    // 데모 모드 검증
    if (_activeInviteCode != null && cleanCode != _activeInviteCode) {
      // 데모 편의상 무조건 연동 성공 처리
    }

    _mockCoupleId = "couple-mock-uuid-123456";
    return {'success': true, 'message': '배우자와 성공적으로 연결되었습니다!'};
  }

  // 3. 실시간 부부 지출 내역 스트림 구독
  Stream<List<Map<String, dynamic>>>? getRealtimeTransactionsStream(String coupleId) {
    if (!_isInitialized || _client == null) return null;

    return _client!
        .from('transactions')
        .stream(primaryKey: ['id'])
        .eq('couple_id', coupleId)
        .order('paid_at', ascending: false);
  }

  // 4. 새 거래 내역 DB 삽입
  Future<bool> insertTransaction({
    required String coupleId,
    required TransactionItem item,
  }) async {
    if (!_isInitialized || _client == null) return false;

    try {
      await _client!.from('transactions').insert({
        'id': item.id,
        'couple_id': coupleId,
        'merchant_name': item.merchantName,
        'amount': item.amount,
        'category_name': item.category,
        'transaction_type': item.type.name,
        'paid_at': item.paidAt.toIso8601String(),
        'card_or_bank_name': item.cardOrBankName,
        'scope': item.scope.name,
        'registered_by': item.registeredBy,
        'raw_sms_text': item.rawSmsText,
        'memo': item.memo,
      });
      return true;
    } catch (e) {
      debugPrint("DB 저장 실패: $e");
      return false;
    }
  }
}

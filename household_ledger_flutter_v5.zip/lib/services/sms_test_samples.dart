import 'sms_parser_service.dart';

class SmsSampleItem {
  final String cardCompany;
  final String rawText;
  final String expectedCategory;

  const SmsSampleItem({
    required this.cardCompany,
    required this.rawText,
    required this.expectedCategory,
  });
}

class SmsTestSamples {
  static const List<SmsSampleItem> sampleList = [
    SmsSampleItem(
      cardCompany: '신한카드',
      rawText: '[Web발신]\n신한카드승인 김*수(1234) 10/27 12:30 (일시불) 14,500원 스타벅스강남점 누적1,250,000원',
      expectedCategory: '식비/카페',
    ),
    SmsSampleItem(
      cardCompany: 'KB국민카드',
      rawText: '[Web발신]\nKB국민카드 10/27 15:45 48,900원 이마트역삼점 승인',
      expectedCategory: '장보기',
    ),
    SmsSampleItem(
      cardCompany: '삼성카드',
      rawText: '[Web발신]\n삼성카드(5678) 10/27 18:20 38,500원 쿠팡 결제완료',
      expectedCategory: '쇼핑',
    ),
    SmsSampleItem(
      cardCompany: '현대카드',
      rawText: '[Web발신]\n현대카드 승인 10/27 19:10 25,000원 카카오T 택시',
      expectedCategory: '교통/차량',
    ),
    SmsSampleItem(
      cardCompany: '우리카드',
      rawText: '[Web발신]\n우리카드 10/27 20:15 65,000원 올리브영강남점',
      expectedCategory: '의료/건강',
    ),
    SmsSampleItem(
      cardCompany: '카카오뱅크',
      rawText: '[Web발신]\n카카오뱅크 10/27 21:00 배달의민족 28,000원 결제',
      expectedCategory: '식비/카페',
    ),
    SmsSampleItem(
      cardCompany: 'NH농협카드',
      rawText: '[Web발신]\nNH농협카드 10/27 09:15 5,500원 메가커피',
      expectedCategory: '식비/카페',
    ),
    SmsSampleItem(
      cardCompany: '토스뱅크',
      rawText: '[Web발신]\n토스뱅크 10/27 14:00 CGV영화관 15,000원 결제',
      expectedCategory: '문화/취미',
    ),
  ];

  /// 무작위 테스트 문자 반환
  static SmsSampleItem getRandomSample() {
    final list = sampleList;
    list.shuffle();
    return list.first;
  }

  /// 모든 샘플에 대한 파싱 테스트 결과 생성
  static List<ParsedSmsResult> runAllTestParses() {
    return sampleList.map((sample) => SmsParserService.parse(sample.rawText)).toList();
  }
}

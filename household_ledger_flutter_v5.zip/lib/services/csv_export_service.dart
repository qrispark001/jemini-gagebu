import 'dart:convert';
import '../models/transaction.dart';

class CsvExportService {
  /// 지출/수입 내역 리스트를 CSV 텍스트로 변환 (Excel 한글 깨짐 방지 UTF-8 BOM 적용)
  static String generateTransactionsCsv(List<TransactionItem> transactions) {
    StringBuffer buffer = StringBuffer();

    // UTF-8 BOM (Byte Order Mark) 추가 -> Excel에서 한글 깨짐 방지
    buffer.write('\uFEFF');

    // CSV Header
    buffer.writeln('일시,구분,상호명(가맹점),금액,카테고리,결제수단,공개범위,등록자,메모');

    for (var item in transactions) {
      String typeStr = _getTypeString(item.type);
      String scopeStr = item.scope == VisibilityScope.shared ? '우리 함께' : '개인 비공개';
      String formattedDate = '${item.paidAt.year}-${_twoDigits(item.paidAt.month)}-${_twoDigits(item.paidAt.day)} ${_twoDigits(item.paidAt.hour)}:${_twoDigits(item.paidAt.minute)}';
      
      String row = [
        _escapeCsv(formattedDate),
        _escapeCsv(typeStr),
        _escapeCsv(item.merchantName),
        item.amount.toInt().toString(),
        _escapeCsv(item.category),
        _escapeCsv(item.cardOrBankName),
        _escapeCsv(scopeStr),
        _escapeCsv(item.registeredBy),
        _escapeCsv(item.memo),
      ].join(',');

      buffer.writeln(row);
    }

    return buffer.toString();
  }

  /// 월별 카테고리 통계 리포트 CSV 생성
  static String generateCategoryReportCsv(Map<String, double> categoryTotals, double totalExpense) {
    StringBuffer buffer = StringBuffer();
    buffer.write('\uFEFF');

    buffer.writeln('카테고리,합계 금액(원),비율(%)');

    categoryTotals.forEach((category, amount) {
      double ratio = totalExpense > 0 ? (amount / totalExpense) * 100 : 0;
      buffer.writeln('${_escapeCsv(category)},${amount.toInt()},${ratio.toStringAsFixed(1)}%');
    });

    buffer.writeln('총 지출,${totalExpense.toInt()},100.0%');

    return buffer.toString();
  }

  static String _getTypeString(TransactionType type) {
    switch (type) {
      case TransactionType.expense:
        return '지출';
      case TransactionType.income:
        return '수입';
      case TransactionType.cancel:
        return '승인취소';
      case TransactionType.transfer:
        return '이체';
    }
  }

  static String _escapeCsv(String field) {
    if (field.contains(',') || field.contains('"') || field.contains('\n')) {
      return '"${field.replaceAll('"', '""')}"';
    }
    return field;
  }

  static String _twoDigits(int n) {
    if (n >= 10) return "$n";
    return "0$n";
  }
}

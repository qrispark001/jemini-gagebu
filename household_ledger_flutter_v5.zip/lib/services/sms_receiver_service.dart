import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:telephony/telephony.dart';
import '../models/transaction.dart';
import 'sms_parser_service.dart';

// 백그라운드 SMS 수신 핸들러 (Android 네이티브 요구사항)
@pragma('vm:entry-point')
void backGroundSmsHandler(SmsMessage message) {
  debugPrint("Background SMS received: ${message.body}");
}

class SmsReceiverService {
  static final SmsReceiverService _instance = SmsReceiverService._internal();
  factory SmsReceiverService() => _instance;
  SmsReceiverService._internal();

  final Telephony _telephony = Telephony.instance;
  final StreamController<TransactionItem> _incomingSmsStreamController =
      StreamController<TransactionItem>.broadcast();

  Stream<TransactionItem> get onSmsTransactionReceived =>
      _incomingSmsStreamController.stream;

  bool _isListening = false;
  bool get isListening => _isListening;

  // 권한 요청 및 수신 시작
  Future<bool> initAndStartListening() async {
    PermissionStatus status = await Permission.sms.request();
    if (status.isGranted) {
      _listenToSms();
      _isListening = true;
      return true;
    } else {
      debugPrint("SMS 권한이 거부되었습니다.");
      _isListening = false;
      return false;
    }
  }

  void _listenToSms() {
    _telephony.listenIncomingSms(
      onNewMessage: (SmsMessage message) {
        _handleSms(message.body ?? '');
      },
      onBackgroundMessage: backGroundSmsHandler,
      listenInBackground: true,
    );
  }

  void _handleSms(String smsBody) {
    if (smsBody.isEmpty) return;

    // 파싱 실행
    ParsedSmsResult parsed = SmsParserService.parse(smsBody);
    if (parsed.isSuccess && parsed.amount > 0) {
      final newTransaction = TransactionItem(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        merchantName: parsed.merchantName,
        amount: parsed.amount,
        category: parsed.category,
        type: TransactionType.expense,
        paidAt: parsed.paidAt,
        cardOrBankName: parsed.cardName,
        scope: VisibilityScope.shared, // 기본값: 부부 공유
        registeredBy: '문자 자동수집',
        rawSmsText: parsed.rawText,
      );

      _incomingSmsStreamController.add(newTransaction);
    }
  }

  void stopListening() {
    _isListening = false;
  }
}

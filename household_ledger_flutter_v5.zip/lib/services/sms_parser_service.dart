import '../models/transaction.dart';

class ParsedSmsResult {
  final double amount;
  final String merchantName;
  final String cardName;
  final String category;
  final DateTime paidAt;
  final String rawText;
  final bool isSuccess;

  ParsedSmsResult({
    required this.amount,
    required this.merchantName,
    required this.cardName,
    required this.category,
    required this.paidAt,
    required this.rawText,
    required this.isSuccess,
  });
}

class SmsParserService {
  // 카테고리 자동 분류 키워드 맵
  static const Map<String, List<String>> _categoryRules = {
    '식비/카페': [
      '스타벅스', '투썸', '메가커피', '컴포즈', '배달의민족', '요기요', '쿠팡이츠',
      '맥도날드', '식당', '반찬', '카페', '베이커리', '파리바게뜨', '뚜레쥬르',
      '이디야', '아웃백', '애슐리', '한식', '중식', '일식', '치킨', '피자'
    ],
    '장보기': [
      '이마트', '홈플러스', '롯데마트', '하나로마트', '쿠팡', '컬리', '마켓컬리',
      'GS25', 'CU', '세븐일레븐', '다이소', '슈퍼', '식자재', '농협하나로'
    ],
    '교통/차량': [
      '카카오T', '택시', '코레일', 'SRT', '버스', '주유소', 'GS칼텍스',
      'SK에너지', '알뜰주유소', 'S-OIL', 'HD현대오일뱅크', '하이패스', '차량정비', '카카오파킹'
    ],
    '문화/취미': [
      'CGV', '메가박스', '롯데시네마', '넷플릭스', '유튜브', '멜론', '지니',
      '교보문고', 'YES24', '알라딘', '티켓링크', '인터파크', '밀리의서재'
    ],
    '주거/통신': [
      'SKT', 'KT', 'LGU+', '한국전력', '도시가스', '관리비', '아파트',
      '월세', '수도요금', '인터넷'
    ],
    '의료/건강': [
      '약국', '병원', '의원', '내과', '치과', '정형외과', '안과', '피부과',
      '올리브영', '롭스', '한의원'
    ],
    '쇼핑': [
      '무신사', '지그재그', '네이버페이', '11번가', 'G마켓', '옥션',
      '백화점', '아울렛', '에이블리', '29CM', 'SSG'
    ],
  };

  /// 주요 카드사/은행 SMS 정규식 및 파싱 처리
  static ParsedSmsResult parse(String smsText) {
    if (smsText.trim().isEmpty) {
      return ParsedSmsResult(
        amount: 0,
        merchantName: '',
        cardName: '알 수 없음',
        category: '미분류',
        paidAt: DateTime.now(),
        rawText: smsText,
        isSuccess: false,
      );
    }

    String cardName = _detectCardCompany(smsText);
    double amount = 0;
    String merchant = '';
    DateTime paidAt = _extractDateTime(smsText);

    // 1. 카드사별 맞춤 정규식 패턴 파싱
    
    // [신한카드] 신한카드승인 홍*길(1234) 10/27 14:30 (일시불) 15,000원 스타벅스강남점
    final shinhanRegex = RegExp(r'신한카드승인.*?\s([\d,]+)원\s+(.+?)(?:\s+누적|\s+일시불|$)');
    
    // [KB국민카드] KB국민카드 10/27 15:00 25,000원 이마트역삼점 승인
    final kbRegex = RegExp(r'KB국민카드.*?\s([\d,]+)원\s+(.+?)(?:\s+승인|\s+누적|$)');
    
    // [삼성카드] 삼성카드(1234) 10/27 16:20 38,000원 쿠팡 결제완료
    final samsungRegex = RegExp(r'삼성카드.*?\s([\d,]+)원\s+(.+?)(?:\s+결제완료|\s+승인|$)');
    
    // [현대카드] 현대카드 승인 10/27 17:10 12,500원 마켓컬리
    final hyundaiRegex = RegExp(r'현대카드.*?\s([\d,]+)원\s+(.+?)(?:\s+일시불|\s+승인|$)');

    // [카카오뱅크/토스] 10/27 21:30 카카오T 14,800원 출금 / 스타벅스 6,000원 결제
    final kakaoTossRegex = RegExp(r'([^\n\r]+?)\s+([\d,]+)원\s*(?:출금|결제|승인)');

    if (shinhanRegex.hasMatch(smsText)) {
      final match = shinhanRegex.firstMatch(smsText)!;
      amount = _cleanAmount(match.group(1));
      merchant = match.group(2)!.trim();
    } else if (kbRegex.hasMatch(smsText)) {
      final match = kbRegex.firstMatch(smsText)!;
      amount = _cleanAmount(match.group(1));
      merchant = match.group(2)!.trim();
    } else if (samsungRegex.hasMatch(smsText)) {
      final match = samsungRegex.firstMatch(smsText)!;
      amount = _cleanAmount(match.group(1));
      merchant = match.group(2)!.trim();
    } else if (hyundaiRegex.hasMatch(smsText)) {
      final match = hyundaiRegex.firstMatch(smsText)!;
      amount = _cleanAmount(match.group(1));
      merchant = match.group(2)!.trim();
    } else {
      // 2. 범용 추출 정규식
      final amountRegex = RegExp(r'([\d,]+)\s*원');
      final amountMatch = amountRegex.firstMatch(smsText);
      if (amountMatch != null) {
        amount = _cleanAmount(amountMatch.group(1));
      }

      final merchantRegex = RegExp(r'원\s+([^\n\r]+?)(?:\s+승인|\s+누적|\s+일시불|\s*\d{2}/\d{2}|$)');
      final merchantMatch = merchantRegex.firstMatch(smsText);
      if (merchantMatch != null) {
        merchant = merchantMatch.group(1)!.trim();
      } else if (kakaoTossRegex.hasMatch(smsText)) {
        final match = kakaoTossRegex.firstMatch(smsText)!;
        merchant = match.group(1)!.trim();
      }
    }

    if (merchant.isEmpty) {
      merchant = '카드 결제';
    }

    // 3. 카테고리 자동 분류
    String category = _categorize(merchant);

    return ParsedSmsResult(
      amount: amount,
      merchantName: merchant,
      cardName: cardName,
      category: category,
      paidAt: paidAt,
      rawText: smsText,
      isSuccess: amount > 0,
    );
  }

  static double _cleanAmount(String? raw) {
    if (raw == null) return 0;
    String cleanStr = raw.replaceAll(',', '').replaceAll('원', '').trim();
    return double.tryParse(cleanStr) ?? 0;
  }

  static DateTime _extractDateTime(String text) {
    final dateRegex = RegExp(r'(\d{2})/(\d{2})\s+(\d{2}):(\d{2})');
    final match = dateRegex.firstMatch(text);
    if (match != null) {
      int month = int.parse(match.group(1)!);
      int day = int.parse(match.group(2)!);
      int hour = int.parse(match.group(3)!);
      int minute = int.parse(match.group(4)!);
      DateTime now = DateTime.now();
      return DateTime(now.year, month, day, hour, minute);
    }
    return DateTime.now();
  }

  static String _detectCardCompany(String text) {
    if (text.contains('신한')) return '신한카드';
    if (text.contains('KB') || text.contains('국민')) return 'KB국민카드';
    if (text.contains('삼성')) return '삼성카드';
    if (text.contains('현대')) return '현대카드';
    if (text.contains('롯데')) return '롯데카드';
    if (text.contains('우리')) return '우리카드';
    if (text.contains('하나')) return '하나카드';
    if (text.contains('NH') || text.contains('농협')) return 'NH농협카드';
    if (text.contains('카카오')) return '카카오뱅크';
    if (text.contains('토스')) return '토스뱅크';
    if (text.contains('BC') || text.contains('비씨')) return 'BC카드';
    return '기타 카드';
  }

  static String _categorize(String merchant) {
    String cleanMerchant = merchant.replaceAll(' ', '').toLowerCase();
    for (var entry in _categoryRules.entries) {
      for (var keyword in entry.value) {
        if (cleanMerchant.contains(keyword.toLowerCase())) {
          return entry.key;
        }
      }
    }
    return '기타';
  }
}
